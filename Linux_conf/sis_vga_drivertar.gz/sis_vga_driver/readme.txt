
1. !!! backup your files. !!!

2. install   
cp sig*.so /usr/lib/xorg/modules/drivers/
cp xorg.conf /etc/X11/
